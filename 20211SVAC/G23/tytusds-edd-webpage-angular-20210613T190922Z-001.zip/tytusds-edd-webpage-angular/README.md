# TyTusDs Estructura de Datos
# Nataly Chavez
# El menu se basa en proyecto:
https://github.com/start-angular/SB-Admin-BS4-Angular-8.git

### Como iniciar

**Nota** se requiere **node >=v8.9.0 and npm >=4**.

Para iniciar el proyecto hacer lo siguiente:

```bash
$ cd SB-Admin-BS4-Angular-8
# instalar las dependencias del proyecto:
$ npm install
# para iniciar el proyecto usar el comando `npm start` para un servidor de desarrollo, luego navegar a `http://localhost:4200/`. 
$ npm start
# para desplegar a produccion , se construye asi
$ npm run build
```

### Generar componentes nuevos

Ejecutar `ng generate component component-name` 

