export class JsonNodo
{
    constructor(public categoria:string,
        public nombre:string,
        public valores:string[]) {}
}
